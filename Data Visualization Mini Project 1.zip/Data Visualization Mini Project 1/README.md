# Billboard Summer Hits: A Sonic Journey Through Six Decades (1958–2017)

**Author:** Owen Telis - Otelis0019@floridapoly.edu  
**Course:** Data Visualization  
**Due Date:** 06-06-2026

---

## Project Overview

This project analyzes Spotify audio features for Billboard summer hits spanning from 1958 to 2017. The dataset contains 600 songs and includes audio metrics such as danceability, energy, valence, acousticness, loudness, and tempo. The goal is to explore how the sound of summer hits has changed over time and identify patterns that define the "summer sound."

---

## Dataset

**File:** `data/all_billboard_summer_hits.csv`  
**Source:** Spotify / Billboard Summer Hits (via course GitHub repository)  
**Rows:** 600 songs  
**Year range:** 1958 to 2017

Key variables used in the analysis:

| Variable | Description |
|---|---|
| `danceability` | How suitable a track is for dancing (0-1) |
| `energy` | Perceptual measure of intensity and activity (0-1) |
| `valence` | Musical positiveness/happiness (0-1) |
| `acousticness` | Confidence the track is acoustic (0-1) |
| `loudness` | Overall loudness in decibels (dB) |
| `tempo` | Estimated tempo in beats per minute (BPM) |
| `year` | Year the song appeared on the Billboard summer chart |

---

## Project Structure

```
Data Visualization Mini Project 1/
|- Data Visualization Mini Project 1.Rproj
|- data/
|--- all_billboard_summer_hits.csv
|- report/
|--- Data Visualization Mini-Project OT.Rmd
|--- Data-Visualization-Mini-Project-OT.html
|- README.md
```

---

## How to Reproduce

1. Open `Data Visualization Mini Project 1.Rproj` in RStudio.
2. Make sure the following R packages are installed:
   - `ggplot2`
   - `dplyr`
   - `tidyr`
   - `scales`
3. Open `report/Data Visualization Mini-Project OT.Rmd`.
4. Click **Knit** to render the HTML report.

## NOTE: File MUST be unzipped for relative path to work properly. Please do not run the file inside of the zip folder. Unzip to new folder on desktop.

The data file is read using a relative path (`../data/all_billboard_summer_hits.csv`) so no changes to the code are needed as long as the folder structure above is intact.

---

## Visualizations

The report includes three visualizations:

1. **Audio Feature Trends by Decade** - A faceted line chart tracking danceability, energy, valence, and acousticness from the 1950s through the 2010s.
2. **Loudness Over Time** - A scatter and line chart showing how average track loudness has increased across decades, with individual song points layered underneath.
3. **Danceability vs. Valence by Era** - A scatterplot comparing the rhythmic and emotional character of summer hits across six eras, with era average centroids labeled.
